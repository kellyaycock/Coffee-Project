public class HotWater extends CoffeeDecorator {
    public HotWater(Coffee coffee) {
        super(coffee);
    }

    public void addTopping(Coffee coffee) {
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " with hot water";
    }

    @Override
    public double cost() {
        return this.coffee.cost() + 0.0;
    }
}
