public class Espresso extends CoffeeDecorator {
    public Espresso(Coffee coffee) {
        super(coffee);
    }

    public void addTopping(Coffee coffee) {
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " with espresso";
    }

    @Override
    public double cost() {
        return this.coffee.cost() + 0.35;
    }
}
