/**
 * Coffee Application Project
 * CS 160L
 * June 30, 2022
 * @author Kelly Aycock
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static int[] inventory = inventoryReader();
    public static String option;
    public static Stack<String> temp = new Stack<>();
    public static void main (String[] args) {
        ArrayList<String> item = new ArrayList<>();
        ArrayList<Double> price = new ArrayList<>();
        ArrayList<Coffee> Temp2;
        int i;
        Scanner CafeApplication = new Scanner(System.in);
        Stack<String> orders = new Stack<>();

        System.out.println("Cafe Application Running...");
        int input = 0;
        while (input != 1) {
            System.out.println("Press 1: Read Inventory");
            System.out.println("Press 2: Create Coffee Order");
            System.out.println("Press 3: Update Inventory");
            System.out.println("Press 4: Update log file");
            System.out.println("Press 5: Exit the application");
            switch (CafeApplication.nextLine()) {
                case "1":
                    System.out.println("Current items in inventory:");
                    System.out.println("Black Coffee = " + inventory[0]);
                    System.out.println("Milk = " + inventory[1]);
                    System.out.println("HotWater = " + inventory[2]);
                    System.out.println("Espresso = " + inventory[3]);
                    System.out.println("Sugar = " + inventory[4]);
                    System.out.println("WhippedCream = " + inventory[5]);
                    break;
                case "2":
                    if (inventory[0] > 0) {
                        String line = "yes";
                        do {
                            System.out.println("Would you like iced coffee or hot coffee?");
                            option = CafeApplication.nextLine();
                            switch (option) {
                                case "iced":
                                    option = "ICED";
                                    temp.push(option);
                                    break;
                                case "hot":
                                    option = "HOT";
                                    temp.push(option);
                                    break;
                                default:
                                    System.out.println("Invalid option. Please press any key to restart.");
                                    continue;
                            }
                            System.out.println("Coffee order created. Select toppings for the first coffee:");
                            Temp2 = createOrder();
                            for (i = 0; i < Temp2.size(); ++i) {
                                item.add(Temp2.get(i).printCoffee());
                                price.add(Temp2.get(i).cost());
                            }
                            System.out.println("Do you want to add another coffee to this order? - yes or no");
                        }   while (!(line = CafeApplication.nextLine()).equals("no"));
                        orders.push(printOrder(item, price));
                        try {
                            FileWriter fileWriter = new FileWriter("coffee.txt");
                            fileWriter.write(orders.pop());
                            fileWriter.close();
                        }   catch (IOException e) {
                            System.out.println("There has been an error.");
                        }
                    }
                    else {
                        System.out.println("Out of coffee. Visit us later.");
                    }
                    break;
                case "3":
                    inventoryWriter(inventory);
                    break;
                case "4":
                    logWriter(orders);
                    break;
                case "5":
                    input = 1;
                    break;
                default:
                    System.out.println("Invalid Selection. Please try again.");
            }
        }

        try {
            FileWriter fileWriter2 = new FileWriter("inventory.txt");
            fileWriter2.write("Black Coffee = 8\n");
            fileWriter2.write("Milk = 8\n");
            fileWriter2.write("HotWater = 8\n");
            fileWriter2.write("Espresso = 8\n");
            fileWriter2.write("Sugar = 8\n");
            fileWriter2.write("WhippedCream = 8\n");
            fileWriter2.close();
        }   catch (IOException e) {
            System.out.println("There has been an error.");
        }

    }

    /**
     * takes each receipt created in "coffee.txt" and adds it to "LogFile.txt" by reading each line and appending it until the stack is empty
     * @param stack (coffee order)
     * @since lab 5
     */
    public static void logWriter(Stack stack) {
        try {
            FileWriter myWriter = new FileWriter("LogFile.txt", true);
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
            Date date = new Date(System.currentTimeMillis());
            FileReader fileReader = new FileReader("coffee.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuilder info = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                info.append(line);
                info.append(System.lineSeparator());
            }
            bufferedReader.close();
            fileReader.close();
            stack.push(info);
            if (stack.isEmpty()) {
                System.out.println("Nothing to log. Stack is empty.");
            }
            else {
                System.out.println("Successfully updated log file.");
            }
            while (!stack.isEmpty()) {
                myWriter.write("\n\nWriting orders from stack " + formatter.format(date));
                myWriter.write(String.valueOf((stack.pop())));
            }
            myWriter.close();
        }   catch (IOException e) {
            System.out.println("There has been an error.");
        }
    }

    /**
     * overwrites the file "inventory.txt" each time a coffee order is created, so it is clear what the amount of items left are
     * @param array (amount of inventory)
     * @since lab 5
     */
    public static void inventoryWriter(int[] array) {
        array = inventory;
        try {
            FileWriter writer = new FileWriter("inventory.txt", false);
            writer.write("Black Coffee = " + inventory[0]);
            writer.write("\nMilk = " + inventory[1]);
            writer.write("\nHotWater = " + inventory[2]);
            writer.write("\nEspresso = " + inventory[3]);
            writer.write("\nSugar = " + inventory[4]);
            writer.write("\nWhippedCream = " + inventory[5]);
            writer.close();
            System.out.println("Successfully updated the inventory.");
        }   catch (IOException e) {
            System.out.println("There has been an error.");
        }
    }

    /**
     * adds the value of the array "inventory" to the file "inventory.txt" so that it is clear how many items are left
     * @return the updated inventory
     * @since lab 5
     */
    public static int[] inventoryReader() {
        int[] inventory = new int[6];
        ArrayList<String> arrayList = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader("inventory.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            StringBuilder info = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                info.append(line);
                info.append(System.lineSeparator());
                arrayList.add(line.substring(line.length() - 1));
            }
            bufferedReader.close();
            fileReader.close();
        }
        catch (IOException e) {
            System.out.println("There has been an error.");
        }
        for (int i = 0; i < arrayList.size(); ++i) {
            inventory[i] = Integer.parseInt(arrayList.get(i));
        }
        return inventory;
    }

    /**
     * uses a StringBuilder to write the receipt of the orders by listing the items along with the price of each item and the total
     * @param item (ArrayList of each coffee item)
     * @param price (ArrayList of the price of each coffee item)
     * @return the receipt containing the coffee orders
     * @since lab 3
     */
    public static String printOrder(ArrayList<String>item, ArrayList<Double>price) {
        Iterator<String>itemList = item.iterator();
        Iterator<Double>priceList = price.iterator();
        double totalPrice = 0.0;
        int i = 1;

        StringBuilder str = new StringBuilder("\nRECEIPT\n");
        while (itemList.hasNext() && priceList.hasNext()) {
            double itemPrice = priceList.next();
            str.append("Item " + i + ": [" + temp.pop() + "] " + itemList.next() + " | Cost: " + itemPrice + "\n");
            totalPrice += itemPrice;
            ++i;
        }
        str.append("TOTAL COST OF ORDER: " + totalPrice);

        return str.toString();
    }

    /**
     * scans what the user types in order to create a coffee object by wrapping each desired class; updates the inventory array according to the selected toppings
     * @return the ArrayList of the coffee item
     * @since lab 4
     */
    public static ArrayList<Coffee> createOrder() {
        Scanner userFeedback = new Scanner(System.in);
        ArrayList<Coffee> coffeeOrder = new ArrayList<>();
        Coffee basicCoffee = new BasicCoffee();
        int in = 0;
        inventory[0] = inventory[0] - 1;

        while (in != 1) {
            System.out.println("Enter the following values to add toppings: 1.) milk, 2.) hot water, 3.) espresso, 4.) sugar, 5) whipped cream, e - to complete order");
            switch (userFeedback.nextLine()) {
                case "1":
                    if (inventory[1] != 0) {
                        basicCoffee = new Milk(basicCoffee);
                        inventory[1] = inventory[1] - 1;
                    } else {
                        System.out.println("Out of milk. Try a different toppings.");
                    }
                    break;
                case "2":
                    if (inventory[2] != 0) {
                        basicCoffee = new HotWater(basicCoffee);
                        inventory[2] = inventory[2] - 1;
                    } else {
                        System.out.println("Out of hot water. Try a different toppings.");
                    }
                    break;
                case "3":
                    if (inventory[3] != 0) {
                        basicCoffee = new Espresso(basicCoffee);
                        inventory[3] = inventory[3] - 1;
                    } else {
                        System.out.println("Out of espresso. Try a different toppings.");
                    }
                    break;
                case "4":
                    if (inventory[4] != 0) {
                        basicCoffee = new Sugar(basicCoffee);
                        inventory[4] = inventory[4] - 1;
                    } else {
                        System.out.println("Out of sugar. Try a different toppings.");
                    }
                    break;
                case "5":
                    if (inventory[5] != 0) {
                        basicCoffee = new WhippedCream(basicCoffee);
                        inventory[5] = inventory[5] - 1;
                    } else {
                        System.out.println("Out of whipped cream. Try a different toppings.");
                    }
                    break;
                case "e":
                    in = 1;
                    break;
                default:
                    System.out.println("Invalid Input");
            }
        }
        coffeeOrder.add(basicCoffee);
        return coffeeOrder;
    }
}
