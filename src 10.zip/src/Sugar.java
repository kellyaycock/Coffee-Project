public class Sugar extends CoffeeDecorator {
    public Sugar(Coffee Coffee) {
        super(Coffee);
    }

    public void addTopping(Coffee coffee) {
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " with sugar";
    }

    @Override
    public double cost() {
        return this.coffee.cost() + 0.05;
    }
}