public class BasicCoffee implements Coffee {
    @Override
    public void addTopping(Coffee coffee) {
    }
    @Override
    public String printCoffee() {
        return "A black coffee";
    }
    @Override
    public double cost() {
        return 0.85;
    }
}
