public class WhippedCream extends CoffeeDecorator {
    public WhippedCream(Coffee coffee) {
        super(coffee);
    }

    public void addTopping(Coffee coffee) {
        this.coffee = coffee;
    }

    @Override
    public String printCoffee() {
        return this.coffee.printCoffee() + " with whipped cream";
    }

    @Override
    public double cost() {
        return this.coffee.cost() + 0.10;
    }
}
